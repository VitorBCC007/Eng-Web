# Eng-software
<hr>
Tecnologias utilizadas:
<br>
• Docker
• vscode
• node:19
• Postegress
• Html
• Css
• Javascript
<br>
<br>
Comandos Utilizados:
<br><br>
USADOS DENTRO DO DIRETORIO SITE
<br>
1) Npm init –y
2) Npm install
3) Npm install nodemon
4) Npm install express
<br>
<br>
USADOS DENTRO DO DIRETORIO RAIZ
<br>
1) Docker-compose up
2) Cd site
3) Npm start
